# WiFi Passview [![huntr](https://cdn.huntr.dev/huntr_security_badge_mono.svg)](https://huntr.dev)

If you discover any security related issue in this repository or in this project, please contact me with this email [security@warengonzaga.com](mailto:security@warengonzaga.com) or [submit a vulnerability report](https://huntr.dev/bounties/disclose/) via [huntr.dev](https://huntr.dev).

Thanks for helping me making my open-source projects safe for everyone, I really appreciate it.

---

💻💖☕ by [Waren Gonzaga](https://warengonzaga.com) | [YHWH](https://youtu.be/9vh6Dz9oh8I?t=85) 🙏